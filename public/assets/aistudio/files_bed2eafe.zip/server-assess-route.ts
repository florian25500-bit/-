/**
 * วิธีใช้: ใน server.ts
 *  1) วาง assessment-core.ts ไว้ข้าง server.ts (หรือใน src/server/)
 *  2) ลบ route app.post('/api/assess', ...) เดิมทั้งก้อน แล้วใส่โค้ดด้านล่างแทน
 *  3) ลบ /api/history, /api/history/:id และ POST/DELETE /api/vocabulary ที่เปิดสาธารณะ
 *
 * หมายเหตุ: ยังไม่ได้ทดสอบกับ Gemini API จริงและยังไม่ได้รัน tsc — ต้องทดสอบก่อนใช้งาน
 *  - ตรวจว่า generateContent config รองรับ abortSignal ใน @google/genai เวอร์ชันที่ใช้
 *  - requireAuth ด้านล่างเป็นที่ว่าง: ให้ใส่การ verify Firebase ID token (firebase-admin)
 */
import type { Request, Response } from 'express';
import {
  ASSESSMENT_SCHEMA, buildSystemPrompt, buildUserPrompt, countWords, looksGerman,
  reconcile, validateAndNormalize, type NormalizedAssessment,
} from './assessment-core';

const MAX_WORDS_ACCEPTED = 1500;
const AI_TIMEOUT_MS = 45_000; // เดิม 4,500 ms ซึ่งสั้นเกินไปสำหรับงานนี้

const LABELS: Record<string, [string, string]> = {
  task_fulfillment: ['Aufgabenbewältigung', 'Task Fulfillment'],
  content_development: ['Inhalt & Entwicklung', 'Content Development'],
  vocabulary: ['Wortschatz', 'Vocabulary'],
  grammar: ['Grammatik', 'Grammar'],
  cohesion: ['Kohärenz & Kohäsion', 'Cohesion'],
  register: ['Register & Stil', 'Register & Style'],
  mechanics: ['Rechtschreibung', 'Mechanics'],
};

// จับคู่ subcategory ของ error กับบทเรียนที่มีอยู่จริงใน grammarLessons.ts
const LESSON_BY_HINT: [RegExp, string, string][] = [
  [/WORD_ORDER|VERB_POSITION|NEBENSATZ|SUBORDIN/i, 'lesson-nebensaetze', 'Nebensätze & Verbletztstellung'],
  [/KASUS|CASE|DATIV|AKKUSATIV|GENITIV/i, 'lesson-kasus', 'Kasus'],
  [/ADJEKTIV|ENDUNG/i, 'lesson-adjektivendungen', 'Adjektivendungen'],
  [/PASSIV/i, 'lesson-passiv', 'Passiv'],
  [/KONJUNKTIV/i, 'lesson-konjunktiv-2', 'Konjunktiv II'],
  [/CONNECTOR|KONNEKTOR|COHESION/i, 'lesson-konnektoren-b2', 'Konnektoren'],
  [/PRAEPOSITION|PREPOSITION|WECHSEL/i, 'lesson-wechselpraepositionen', 'Wechselpräpositionen'],
];

function toLegacyShape(a: NormalizedAssessment, task: any, text: string) {
  const bands = Object.fromEntries(a.category_scores.map((s) => [s.category, s.band]));
  const recs = new Map<string, any>();
  for (const e of a.errors) {
    const hit = LESSON_BY_HINT.find(([re]) => re.test(e.subcategory));
    if (hit && !recs.has(hit[1])) {
      recs.set(hit[1], {
        topic: hit[2], priority: e.severity === 'major' ? 'high' : 'medium', lesson_id: hit[1],
        reason_th: `พบข้อผิดพลาดที่เกี่ยวข้อง เช่น “${e.original_text}”`,
        action_th: 'ทบทวนบทเรียนนี้ แล้วลองแก้ประโยคที่ถูกไฮไลต์ด้วยตัวเอง',
      });
    }
  }
  const confTh = { high: 'สูง', medium: 'ปานกลาง', low: 'ต่ำ' }[a.confidence];
  return {
    id: `assess-${Date.now()}`, submission_id: `sub-${Date.now()}`,
    task_id: task.id, task_title: task.title, task_level: task.cefr_level, task_category: task.category,
    original_text: text, word_count: a.word_count,
    total_score: a.total_score, grade: a.grade,
    cefr_estimate: a.cefr_estimate, cefr_confidence: a.confidence,
    cefr_summary_th: `ประเมินเป็นระดับ ${a.cefr_estimate} (ความเชื่อมั่นของผลตรวจ: ${confTh}) — เป็นการประเมินจากงานเขียนชิ้นนี้ชิ้นเดียว ไม่ใช่ผลสอบอย่างเป็นทางการ`,
    main_weakness_th: a.weaknesses_th[0] || '', main_strength_th: a.strengths_th[0] || '',
    cefr_profile: bands,
    category_scores: a.category_scores.map((s) => ({
      category: s.category, label_de: LABELS[s.category][0], label_en: LABELS[s.category][1],
      score: s.score, max_score: s.max_score, feedback_th: s.feedback_th,
    })),
    errors: a.errors.map((e) => ({ ...e, examples: [] })),
    strengths: a.strengths_th, weaknesses: a.weaknesses_th,
    // เวอร์ชัน b2/c1 ควรสร้างแยกเมื่อผู้ใช้กดขอ (เรียก AI อีกครั้ง) — ที่นี่เว้นว่างแทนข้อความสำเร็จรูป
    writing_versions: { corrected: a.corrected, b2_improved: '', c1_model: '' },
    learning_recommendations: [...recs.values()].slice(0, 3),
    engine: a.engine, prompt_version: a.prompt_version, quality: a.quality,
    rubric_version: '4.0', created_at: new Date().toISOString(),
  };
}

export function registerAssessRoute(app: any, deps: { aiClient: any; findTask: (id: string) => any; requireAuth: any }) {
  const { aiClient, findTask, requireAuth } = deps;

  async function runOnce(task: any, text: string, wc: number): Promise<NormalizedAssessment | null> {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), AI_TIMEOUT_MS);
    try {
      const res = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: buildUserPrompt(task, text, wc),
        config: {
          systemInstruction: buildSystemPrompt(task.cefr_level),
          responseMimeType: 'application/json',
          responseSchema: ASSESSMENT_SCHEMA as any,
          temperature: 0.2,
          abortSignal: ctrl.signal,
        },
      });
      const v = validateAndNormalize(JSON.parse(res.text || '{}'), text, task);
      if (!v.ok) { console.warn('[assess] invalid:', v.code, v.reasons); return null; }
      return v.result;
    } catch (err) {
      console.warn('[assess] call failed:', err);
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  app.post('/api/assess', requireAuth, async (req: Request, res: Response) => {
    const { task_id, original_text } = req.body ?? {};
    if (typeof original_text !== 'string' || !original_text.trim()) return res.status(400).json({ error: 'EMPTY_TEXT' });
    const task = findTask(String(task_id));
    if (!task) return res.status(404).json({ error: 'TASK_NOT_FOUND' }); // ห้าม fallback ไปโจทย์ข้อแรก

    const wc = countWords(original_text);
    if (wc > MAX_WORDS_ACCEPTED) return res.status(413).json({ error: 'TEXT_TOO_LONG', max_words: MAX_WORDS_ACCEPTED });
    if (!looksGerman(original_text)) {
      return res.status(422).json({ error: 'NOT_GERMAN', message_th: 'ข้อความดูเหมือนไม่ใช่ภาษาเยอรมัน จึงยังไม่ตรวจให้' });
    }
    if (!aiClient) return res.status(503).json({ error: 'AI_UNAVAILABLE', message_th: 'ระบบตรวจยังไม่พร้อมใช้งาน' });

    // 2 รอบพร้อมกัน แล้ว reconcile; ถ้าสำเร็จรอบเดียวให้ลดความเชื่อมั่น; ถ้าล้มทั้งคู่ลองซ้ำอีก 1 ครั้ง
    let [a, b] = await Promise.all([runOnce(task, original_text, wc), runOnce(task, original_text, wc)]);
    if (!a && !b) a = await runOnce(task, original_text, wc);

    let final: NormalizedAssessment | null = null;
    if (a && b) final = reconcile(a, b);
    else if (a || b) {
      final = (a || b)!;
      if (final.confidence === 'high') final = { ...final, confidence: 'medium' };
    }
    if (!final) {
      return res.status(502).json({ error: 'ASSESSMENT_FAILED', message_th: 'ตรวจไม่สำเร็จ กรุณาลองใหม่อีกครั้ง (ไม่มีการให้คะแนนปลอม)' });
    }
    return res.json({ assessment: toLegacyShape(final, task, original_text) });
  });
}
